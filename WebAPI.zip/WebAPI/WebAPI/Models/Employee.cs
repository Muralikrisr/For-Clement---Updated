﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WebAPI.Models
{
    public class Employee
    {
        [Key]
        public int id { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string firstName { get; set; }

        [Column(TypeName = "nvarchar(16)")]
        public string lastName { get; set; }

        [Column(TypeName = "nvarchar(100)")]
        public string joinedDate { get; set; }

        public int age { get; set; }

        [Column(TypeName = "nvarchar(10)")]
        public string Gender { get; set; }
    }
}
