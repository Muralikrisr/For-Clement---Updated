import React, { useState, useEffect } from "react";
import { Grid, TextField, withStyles, FormControl, InputLabel, Select, MenuItem, Button, FormHelperText } from "@material-ui/core";
import useForm from "./processForm";
import { connect } from "react-redux";
import * as actions from "../actions/crudActions";
import { useToasts } from "react-toast-notifications";

const customStyles = theme => ({
    root: {
        '& .MuiTextField-root': {
            margin: theme.spacing(1),
            minWidth: 180,
        }
    },
    formControl: {
        margin: theme.spacing(1),
        minWidth: 180,
    },
    smMargin: {
        margin: theme.spacing(0.5)
    },
    TextField:{
        marginLeft: theme.spacing(7),
    }
})

const initialFieldValues = {
    firstName: '',
    lastName: '',
    gender: '',
    joinedDate: '',
    age: ''
}

const EmployeeForm = ({ classes, ...props }) => {

    const { addToast } = useToasts()
    const validate = (fieldValues = values) => {
        let temp = { ...errors }
        if ('firstName' in fieldValues)
            temp.firstName = fieldValues.firstName ? "" : "This field is required."
        if ('lastName' in fieldValues)
            temp.lastName = fieldValues.lastName ? "" : "This field is required."
        if ('age' in fieldValues)
            temp.age = fieldValues.age ? "" : "This field is required."
        if ('gender' in fieldValues)
            temp.gender = fieldValues.gender ? "" : "This field is required."
        if ('joinedDate' in fieldValues)
            temp.joinedDate = fieldValues.joinedDate ? "" : "This field is required."
        
        setErrors({
            ...temp
        })

        if (fieldValues == values)
            return Object.values(temp).every(x => x == "")
    }

    const {
        values,
        setValues,
        errors,
        setErrors,
        handleInputChange,
        resetForm
    } = useForm(initialFieldValues, validate, props.setCurrentId)

    
    const inputLabel = React.useRef(null);
    const [labelWidth, setLabelWidth] = React.useState(0);
    React.useEffect(() => {
        setLabelWidth(inputLabel.current.offsetWidth);
    }, []);

    const handleSubmit = e => {
        e.preventDefault()
        if (validate()) {
            const onSuccess = () => {
                resetForm()
                addToast("Employee Details Saved successfully", { appearance: 'success' })
            }
            if (props.currentId == 0)
                props.createEmployee(values, onSuccess)
            else
                props.updateEmployee(props.currentId, values, onSuccess)
        }
    }

    useEffect(() => {
        if (props.currentId != 0) {
            setValues({
                ...props.employees.find(x => x.id == props.currentId)
            })
            setErrors({})
        }
    }, [props.currentId])

    return (
        <form autoComplete="off" noValidate className={classes.root} onSubmit={handleSubmit}>
            
            <Grid item xs={1}></Grid>
                <Grid className={classes.TextField} item xs={2}>
                    <TextField
                        name="firstName"
                        variant="outlined"
                        label="First Name"
                        value={values.firstName}
                        onChange={handleInputChange}
                        {...(errors.firstName && { error: true, helperText: errors.firstName })}
                    />
                    <TextField
                        name="lastName"
                        variant="outlined"
                        label="Last Name"
                        value={values.lastName}
                        onChange={handleInputChange}
                        {...(errors.lastName && { error: true, helperText: errors.lastName })}
                    />
                    <FormControl variant="outlined"
                        className={classes.formControl}
                        {...(errors.gender && { error: true })}
                    >
                        <InputLabel ref={inputLabel}>Gender</InputLabel>
                        <Select
                            name="gender"
                            value={values.gender}
                            onChange={handleInputChange}
                            labelWidth={labelWidth}
                        >
                            <MenuItem value="">Select Gender</MenuItem>
                            <MenuItem value="Male">Male</MenuItem>
                            <MenuItem value="Female">Female</MenuItem>
                        </Select>
                        {errors.gender && <FormHelperText>{errors.gender}</FormHelperText>}
                    </FormControl>
                    <TextField
                        name="joinedDate"
                        variant="outlined"
                       
                        type="date"
                        value={values.joinedDate}
                        onChange={handleInputChange}
                        {...(errors.joinedDate && { error: true, helperText: errors.joinedDate })}
                    />
                    <TextField
                        name="age"
                        variant="outlined"
                        label="Age"
                        value={values.age}
                        onChange={handleInputChange}
                    />
                <Grid item xs={2}>
                <Button
                            variant="contained"
                            color="primary"
                            type="submit"
                            className={classes.smMargin}
                        >Save</Button>
                        </Grid>
                        <Grid item xs={1}>
                        <Button
                            variant="contained"
                            className={classes.smMargin}
                            onClick={resetForm}
                        >Clear
                        </Button>
                        </Grid>
                </Grid>
        </form>
    );
}

const mapStateToProps = state => ({
    employees: state.employeeReducers.list
})

const mapActionToProps = {
    createEmployee: actions.create,
    updateEmployee: actions.update
}

export default connect(mapStateToProps, mapActionToProps)(withStyles(customStyles)(EmployeeForm));