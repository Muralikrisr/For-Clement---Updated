import React, { useState, useEffect } from "react";
import { connect } from "react-redux";
import * as actions from "../actions/crudActions";
import { Grid, TextField, Paper, TableContainer, Table, TableHead, TableFooter, TablePagination, TableRow, TableCell, TableBody, withStyles, ButtonGroup, Button } from "@material-ui/core";
import EmployeeForm from "./EmployeeForm";
import { useToasts } from "react-toast-notifications";
import PropTypes from 'prop-types';
import '../styles.css';
import IconButton from '@material-ui/core/IconButton';
import FirstPageIcon from '@material-ui/icons/FirstPage';
import KeyboardArrowLeft from '@material-ui/icons/KeyboardArrowLeft';
import KeyboardArrowRight from '@material-ui/icons/KeyboardArrowRight';
import LastPageIcon from '@material-ui/icons/LastPage';
import { makeStyles, useTheme } from '@material-ui/core/styles';

const useSortableData = (items, config = null) => {
    const [sortConfig, setSortConfig] = React.useState(config);
 
    const sortedItems = React.useMemo(() => {
      let sortableItems = [...items];
      
      if (sortConfig !== null) {
        if(sortConfig.filterValue == null)
        {
          sortableItems.sort((a, b) => {
           
            if (a[sortConfig.key] < b[sortConfig.key]) {
              return sortConfig.direction === 'ascending' ? -1 : 1;
            }
            if (a[sortConfig.key] > b[sortConfig.key]) {
              return sortConfig.direction === 'ascending' ? 1 : -1;
            }
            return 0;
          });
        }
        else if(sortConfig.filterValue != null)
        {
          sortableItems = sortableItems.filter(e => e.firstName.toLowerCase().includes(sortConfig.filterValue.toLowerCase()) ||
          e.lastName.toLowerCase().includes(sortConfig.filterValue.toLowerCase()) ||
          e.gender.toLowerCase().includes(sortConfig.filterValue.toLowerCase()) ||
          e.age.toString().toLowerCase().includes(sortConfig.filterValue.toLowerCase()) ||
          e.joinedDate.toString().includes(sortConfig.filterValue.toLowerCase())
          );
        }
       
      }
      return sortableItems;
    }, [items, sortConfig]);
 
    const requestSort = (key) => {
      let direction = 'ascending';
      if (
        sortConfig &&
        sortConfig.key === key &&
        sortConfig.direction === 'ascending'
      ) {
        direction = 'descending';
      }
      setSortConfig({ key, direction });
    };
   

    const searchFilter = (filterValue) => {
      setSortConfig({filterValue});
    }
 
    return { items: sortedItems, requestSort, sortConfig, searchFilter };
  };

const styles = theme => ({
    root: {
        "& .MuiTableCell-head": {
            fontSize: "1.25rem"
        }
    },
    paper: {
         padding: theme.spacing(2)
    },
    ml20:
    {
      margin: theme.spacing(1)
    },
    table: {
  },
  h2:{
    marginLeft: theme.spacing(-5),
  }
  
})

const paginationStyles = makeStyles((theme) => ({
  root: {
    flexShrink: 0,
    marginLeft: theme.spacing(2.5),
  },
}));

function TablePaginationActions(props) {
  const classes = paginationStyles();
  const theme = useTheme();
  const { count, page, rowsPerPage, onChangePage } = props;

  const handleFirstPageButtonClick = (event) => {
    onChangePage(event, 0);
  };

  const handleBackButtonClick = (event) => {
    onChangePage(event, page - 1);
  };

  const handleNextButtonClick = (event) => {
    onChangePage(event, page + 1);
  };

  const handleLastPageButtonClick = (event) => {
    onChangePage(event, Math.max(0, Math.ceil(count / rowsPerPage) - 1));
  }; 

  return (
    <div className={classes.root}>
      <IconButton
        onClick={handleFirstPageButtonClick}
        disabled={page === 0}
        aria-label="first page"
      >
        {theme.direction === 'rtl' ? <LastPageIcon /> : <FirstPageIcon />}
      </IconButton>
      <IconButton onClick={handleBackButtonClick} disabled={page === 0} aria-label="previous page">
        {theme.direction === 'rtl' ? <KeyboardArrowRight /> : <KeyboardArrowLeft />}
      </IconButton>
      <IconButton
        onClick={handleNextButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="next page"
      >
        {theme.direction === 'rtl' ? <KeyboardArrowLeft /> : <KeyboardArrowRight />}
      </IconButton>
      <IconButton
        onClick={handleLastPageButtonClick}
        disabled={page >= Math.ceil(count / rowsPerPage) - 1}
        aria-label="last page"
      >
        {theme.direction === 'rtl' ? <FirstPageIcon /> : <LastPageIcon />}
      </IconButton>
    </div>
  );
}

TablePaginationActions.propTypes = {
  count: PropTypes.number.isRequired,
  onChangePage: PropTypes.func.isRequired,
  page: PropTypes.number.isRequired,
  rowsPerPage: PropTypes.number.isRequired,
};


const Employee = ({ classes, ...props }) => {
    const [value, setValues] = useState('')

  const handleChange = (event) => {
    setValues(event.target.value);
    searchFilter(event.target.value);
  }

  const handleSubmit = (event) => {
    console.log(value);
    searchFilter(value);
  }
  const [state] = React.useState(0);
    const [page, setPage] = React.useState(0);
    const [rowsPerPage, setRowsPerPage] = React.useState(10);
 
    const emptyRows = rowsPerPage - Math.min(rowsPerPage, props.employees.length - page * rowsPerPage);
 
    const handleChangePage = (event, newPage) => {
      setPage(newPage);
    };
   

    const handleChangeRowsPerPage = (event) => {
      setRowsPerPage(parseInt(event.target.value, 10));
      setPage(0);
    };


    const { items, requestSort, sortConfig, searchFilter } = useSortableData(props.employees);
  const getClassNamesFor = (name) => {
     
    if (!sortConfig) {
      return;
    }
    
    return sortConfig.key === name ? sortConfig.direction : undefined;
  };

    const [currentId, setCurrentId] = useState(0)

    useEffect(() => {
        props.fetchAllEmployee()
    }, [])
   
    const { addToast } = useToasts()

    const onDelete = id => {
        if (window.confirm('Are you sure to delete this record?'))
            props.deleteEmployee(id,()=>addToast("Employee deleted successfully", { appearance: 'info' }))
    }
    return (
        <Paper elevation={3}>
            <Grid container>
              <Grid item xs={10}>
              <TextField className={classes.ml20}
                        name="search"
                        variant="outlined"
                        label="Find Employee"
                        value = {value}
                        onChange={handleChange}/>
                    </Grid>
              <Grid item xs={2}>
                <h2 className={classes.h2}>Create/Edit</h2>
                    </Grid>
                <Grid item xs={9}>
                    <TableContainer>
                        <Table  className={classes.table} size="small" aria-label="a dense table" className={classes.table} size="small" aria-label="a dense table">
                            <TableHead className={classes.root}>
                                <TableRow>
                                    <TableCell>
                                    <a onClick={() => requestSort('firstName')}
                                    className={getClassNamesFor('firstName')}>First Name</a>
                                    </TableCell>
                                    <TableCell>
                                      <a onClick={() => requestSort('lastName')}
                                    className={getClassNamesFor('lastName')}>Last Name</a></TableCell>
                                    <TableCell><a onClick={() => requestSort('gender')}
                                    className={getClassNamesFor('gender')}>Gender</a></TableCell>
                                    <TableCell><a onClick={() => requestSort('age')}
                                    className={getClassNamesFor('age')}>Age</a></TableCell>
                                    <TableCell><a onClick={() => requestSort('joinedDate')} className={getClassNamesFor('joinedDate')}>Date of Joining</a></TableCell>
                                    <TableCell>Action</TableCell>
                                </TableRow>
                            </TableHead>
                            <TableBody>
                                {
                                    (rowsPerPage > 0
                                        ? items.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage)
                                        : items
                                      ).map((record, index) => {
                                        return (<TableRow key={index} hover>
                                            <TableCell>{record.firstName}</TableCell>
                                            <TableCell>{record.lastName}</TableCell>
                                            <TableCell>{record.gender}</TableCell>
                                            <TableCell>{record.age}</TableCell>
                                            <TableCell>{record.joinedDate}</TableCell>
                                            <TableCell>
                                                <ButtonGroup variant="text">
                                                    <Button color="primary" onClick={() => { setCurrentId(record.id) }}>Edit</Button>
                                                    <Button color="secondary" onClick={() => onDelete(record.id)} >Delete</Button>
                                                </ButtonGroup>
                                            </TableCell>
                                        </TableRow>)
                                    })
                                }
                            </TableBody>
                            <TableFooter>
          
            <TablePagination
              rowsPerPageOptions={[10, { label: 'All', value: -1 }]}
              colSpan={12}
              count={items.length}
              rowsPerPage={rowsPerPage}
              page={page}
              SelectProps={{
                inputProps: { 'aria-label': 'rows per page' },
                native: true,
              }}
              onChangePage={handleChangePage}
              onChangeRowsPerPage={handleChangeRowsPerPage}
              ActionsComponent={TablePaginationActions}
            />
        </TableFooter>
                        </Table>
                    </TableContainer>
                </Grid>
                <Grid item xs={3}>
                    <EmployeeForm {...({ currentId, setCurrentId })} />
                </Grid>
                            </Grid>
        </Paper>
    );
}

const mapStateToProps = state => ({
    employees: state.employeeReducers.list
})

const mapActionToProps = {
    fetchAllEmployee: actions.fetchAll,
    deleteEmployee: actions.Delete
}

export default connect(mapStateToProps, mapActionToProps)(withStyles(styles)(Employee));